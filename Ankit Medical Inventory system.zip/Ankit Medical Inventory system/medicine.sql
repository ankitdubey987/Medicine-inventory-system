-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2019 at 04:19 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicine`
--

-- --------------------------------------------------------

--
-- Table structure for table `medicine_table`
--

CREATE TABLE `medicine_table` (
  `medicine_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `expiry` varchar(25) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `mfd_date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `puchase_table`
--

CREATE TABLE `puchase_table` (
  `purchase_id` int(11) NOT NULL,
  `Seller_id` int(11) NOT NULL,
  `seller_name` varchar(255) NOT NULL,
  `Address` varchar(45) DEFAULT NULL,
  `contact_number` decimal(10,0) NOT NULL,
  `quantity` float NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `puchase_table`
--

INSERT INTO `puchase_table` (`purchase_id`, `Seller_id`, `seller_name`, `Address`, `contact_number`, `quantity`, `price`) VALUES
(1, 1, 'ankit dubey', 'ranopali', '0', 99, 100),
(2, 23, 'anil jaiswal', 'ram ghr tal', '8898989899', 34, 120);

-- --------------------------------------------------------

--
-- Table structure for table `sales_table`
--

CREATE TABLE `sales_table` (
  `customer_name` varchar(255) NOT NULL,
  `medicine_id` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `date` date NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `qty` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_table`
--

INSERT INTO `sales_table` (`customer_name`, `medicine_id`, `price`, `date`, `contact_number`, `qty`) VALUES
('Ankit Dubey', 'Paracetamol', 100, '2019-02-05', '', 12);

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `contact_number` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`fname`, `lname`, `email`, `password`, `contact_number`) VALUES
('test User', '0000000000', 'akdbitcoin@gmail.com', 'test', '0'),
('Ankit Kumar', '8840609507', 'dubey7816@gmail.com', 'admin', '8840609507'),
('test User', '0000000000', 'dubeyTest@gmail.com', 'test', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medicine_table`
--
ALTER TABLE `medicine_table`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `puchase_table`
--
ALTER TABLE `puchase_table`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `sales_table`
--
ALTER TABLE `sales_table`
  ADD PRIMARY KEY (`customer_name`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
